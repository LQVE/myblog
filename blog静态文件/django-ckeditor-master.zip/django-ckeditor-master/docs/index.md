Howdy!

See [installation](INSTALL.md) and [usage](USAGE.md) sections.
